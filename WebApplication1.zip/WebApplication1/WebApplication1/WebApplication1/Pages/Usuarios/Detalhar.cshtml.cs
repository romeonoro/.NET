using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Pages.Usuarios
{
    public class DetalharModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
