﻿using System.ComponentModel.DataAnnotations;

namespace WebVehicles.Models
{
    public class Veiculo
    {
        public string Nome { get; set; } = string.Empty;
        public string Modelo { get; set; } = string.Empty;
        public string Marca { get; set; } = string.Empty;
        public string Renavam { get; set; } = string.Empty;
        [Display(Name = "Ano de Fabricação")]
        public int AnoFabricacao { get; set; }
        [Display(Name = "Ano do Modelo")]
        public int AnoModelo { get; set; }
        public string? CaminhoImagem { get; set; } 
    }
}
