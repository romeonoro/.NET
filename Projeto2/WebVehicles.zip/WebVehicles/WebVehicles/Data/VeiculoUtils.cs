﻿using System.Globalization;
using WebVehicles.Models;
namespace WebVehicles.Utils //Data
{
    public static class VeiculoUtils
    {
        public static string CaminhoArquivo => "Data/veiculos.txt";

        public static void Salvar(Veiculo veiculo)
        {
            using var writer = new StreamWriter(CaminhoArquivo, append: true);
            writer.WriteLine($"{veiculo.Nome};{veiculo.Modelo};{veiculo.Marca};{veiculo.Renavam};{veiculo.AnoFabricacao};{veiculo.AnoModelo};{veiculo.CaminhoImagem}");
        }


        public static List<Veiculo> ListarTodos()
        {
            var veiculos = new List<Veiculo>();

            if (!File.Exists(CaminhoArquivo))
                return veiculos;

            var linhas = File.ReadAllLines(CaminhoArquivo);
            foreach (var linha in linhas)
            {
                var dados = linha.Split(';');
                if (dados.Length == 7)
                {
                    veiculos.Add(new Veiculo
                    {
                        Nome = dados[0],
                        Modelo = dados[1],
                        Marca = dados[2],
                        Renavam = dados[3],
                        AnoFabricacao = int.TryParse(dados[4], out int anoFab) ? anoFab : 0,
                        AnoModelo = int.TryParse(dados[5], out int anoMod) ? anoMod : 0,
                        CaminhoImagem = dados[6]
                    });
                }
            }

            return veiculos;
        }

        public static Veiculo? ObterPorRenavam(string renavam)
        {
            return ListarTodos().FirstOrDefault(v => v.Renavam == renavam);
        }

        public static void Atualizar(Veiculo atualizado)
        {
            var veiculos = ListarTodos();
            var index = veiculos.FindIndex(v => v.Renavam == atualizado.Renavam);
            if (index != -1)
            {
                veiculos[index] = atualizado;

                var linhas = veiculos.Select(v =>
                    $"{v.Nome};{v.Modelo};{v.Marca};{v.Renavam};{v.AnoFabricacao};{v.AnoModelo};{v.CaminhoImagem}");
                File.WriteAllLines(CaminhoArquivo, linhas);
            }
        }

        public static void Excluir(string renavam)
        {
            var veiculos = ListarTodos()
                .Where(v => v.Renavam != renavam)
                .Select(v => $"{v.Nome};{v.Modelo};{v.Marca};{v.Renavam};{v.AnoFabricacao};{v.AnoModelo};{v.CaminhoImagem}")
                .ToList();

            File.WriteAllLines(CaminhoArquivo, veiculos);
        }
    }
}
