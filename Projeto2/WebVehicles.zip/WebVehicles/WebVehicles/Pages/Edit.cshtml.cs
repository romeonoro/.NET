using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebVehicles.Models;
using WebVehicles.Utils;

namespace WebVehicles.Pages
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public Veiculo Veiculo { get; set; } = new Veiculo();

        [BindProperty]
        public IFormFile? NovaImagem { get; set; }

        public IActionResult OnGet(string renavam)
        {
            var veiculo = VeiculoUtils.ObterPorRenavam(renavam);
            if (veiculo == null)
                return RedirectToPage("List");

            Veiculo = veiculo;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            if (NovaImagem != null && NovaImagem.Length > 0)
            {
                var uploadsFolder = Path.Combine("wwwroot", "uploads");

                if (!Directory.Exists(uploadsFolder))
                    Directory.CreateDirectory(uploadsFolder);

                var nomeArquivo = Guid.NewGuid().ToString() + Path.GetExtension(NovaImagem.FileName);
                var caminhoCompleto = Path.Combine(uploadsFolder, nomeArquivo);

                using (var stream = new FileStream(caminhoCompleto, FileMode.Create))
                {
                    NovaImagem.CopyTo(stream);
                }

                Veiculo.CaminhoImagem = "/uploads/" + nomeArquivo;
            }

            VeiculoUtils.Atualizar(Veiculo);

            return RedirectToPage("List");
        }
    }
}
