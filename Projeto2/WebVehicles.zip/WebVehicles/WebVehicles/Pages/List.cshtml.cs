using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebVehicles.Models;
using WebVehicles.Utils;

namespace WebVehicles.Pages
{
    public class ListModel : PageModel
    {
        public List<Veiculo> Veiculos { get; set; } = new();

        public void OnGet()
        {
            Veiculos = VeiculoUtils.ListarTodos();
        }

        public IActionResult OnPostDelete(string renavam)
        {
            if (!string.IsNullOrEmpty(renavam))
            {
                Console.WriteLine($"Tentando excluir ve�culo com Renavam: {renavam}");
                VeiculoUtils.Excluir(renavam);
            }

            return RedirectToPage();
        }

    }
}
