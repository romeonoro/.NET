using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebVehicles.Models;
using WebVehicles.Utils;

namespace WebVehicles.Pages
{
    public class DetailsModel : PageModel
    {
        public Veiculo Veiculo { get; set; } = new Veiculo();

        public IActionResult OnGet(string renavam)
        {
            var veiculo = VeiculoUtils.ObterPorRenavam(renavam);
            if (veiculo == null)
                return RedirectToPage("List");

            Veiculo = veiculo;
            return Page();
        }
    }
}
