using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebVehicles.Models;
using WebVehicles.Utils;
namespace WebVehicles.Pages;

public class CreateModel : PageModel
{
    [BindProperty]
    public Veiculo Veiculo { get; set; } = new Veiculo();

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid) return Page();

        VeiculoUtils.Salvar(Veiculo);

        return RedirectToPage("List");
    }

}

