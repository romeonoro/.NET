﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="O nome é obrigatório")]
        [StringLength(40, ErrorMessage="O nome deve conter até 40 caracteres")]
        public string Nome { get; set; } = string.Empty;
        [Required(ErrorMessage = "O e-mail é obrigatório")]
        [EmailAddress(ErrorMessage = "o e-mail deve ser válido")]
        public string Email { get; set; } = string.Empty;
        [Required(ErrorMessage = "A senha é obrigatória")]
        [StringLength(10, MinimumLength = 6, ErrorMessage = "A senha deve conter entre 6 e 10 caracteres")]
        public string Senha { get; set; } = string.Empty;
    }

}
