using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplication1.Models;

namespace WebApplication1.Pages.Usuarios
{
    public class CriarModel : PageModel
    {
        [BindProperty]
        public Usuario Usuario { get; set; } = new Usuario();

        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                return Page();
            }
            else
            {
                using var writer = new StreamWriter("usuarios.txt", true);
                writer.WriteLine(Usuario.Id + ";" + Usuario.Nome + ";" + Usuario.Email + ";" + Usuario.Senha);
                return RedirectToPage("/Usuarios/Index");
            }
        }

    }
}
