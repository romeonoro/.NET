using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebSuper.Pages.Usuarios
{
    public class DetalharModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
